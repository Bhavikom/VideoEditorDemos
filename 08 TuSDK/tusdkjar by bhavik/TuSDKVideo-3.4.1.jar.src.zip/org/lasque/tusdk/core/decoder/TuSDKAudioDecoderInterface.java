package org.lasque.tusdk.core.decoder;

public abstract interface TuSDKAudioDecoderInterface
  extends TuSDKMediaDecoderInterface
{
  public abstract void onDecode(byte[] paramArrayOfByte, double paramDouble);
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKVideo-3.4.1.jar!\org\lasque\tusdk\core\decoder\TuSDKAudioDecoderInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
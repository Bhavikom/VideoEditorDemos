package org.lasque.tusdk.core.utils.hardware;

public class TuSdkRecorderCameraSetting
{
  public CameraConfigs.CameraFacing facing = CameraConfigs.CameraFacing.Front;
  public float previewEffectScale = -1.0F;
  public int previewMaxSize = -1;
  public float previewRatio = -1.0F;
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKVideo-3.4.1.jar!\org\lasque\tusdk\core\utils\hardware\TuSdkRecorderCameraSetting.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
package org.lasque.tusdk.core.seles.sources;

import org.lasque.tusdk.core.seles.tusdk.FilterWrap;

public abstract interface VideoFilterDelegate
{
  public abstract void onFilterChanged(FilterWrap paramFilterWrap);
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKVideo-3.4.1.jar!\org\lasque\tusdk\core\seles\sources\VideoFilterDelegate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
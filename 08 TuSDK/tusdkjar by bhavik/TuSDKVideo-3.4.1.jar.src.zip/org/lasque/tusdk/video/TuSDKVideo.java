package org.lasque.tusdk.video;

public class TuSDKVideo
{
  public static final String VIDEO_VERSION = "3.4.1";
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKVideo-3.4.1.jar!\org\lasque\tusdk\video\TuSDKVideo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
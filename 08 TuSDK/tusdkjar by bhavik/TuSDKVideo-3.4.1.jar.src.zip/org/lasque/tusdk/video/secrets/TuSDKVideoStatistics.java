package org.lasque.tusdk.video.secrets;

public class TuSDKVideoStatistics
{
  public static final long tkc_liveCamera_start = 9437184L;
  public static final long tkc_liveCamera_stop = 9437185L;
  public static final long tkc_recordCamera_start = 9437186L;
  public static final long tkc_recordCamera_stop = 9437187L;
  public static final long tkc_recordCamera_multi_start = 9441280L;
  public static final long tkc_recordCamera_multi_stop = 9441281L;
  public static final long tkc_recordCamera_multi_finish = 9441282L;
  public static final long tkc_recordCamera_multi_undo = 9441296L;
  public static final long tkc_video_action_faceing_back = 9441313L;
  public static final long tkc_video_action_faceing_front = 9441314L;
  public static final long tkc_video_editor_save = 9445376L;
  public static final long tkc_video_editor_preview_start = 9445377L;
  public static final long tkc_video_editor_preview_stop = 9445378L;
  public static final long tkc_video_editor_save_cut_range = 9445379L;
  public static final long tkc_video_editor_save_add_dub = 9445380L;
  public static final long tkc_video_editor_save_adjust_volume = 9445381L;
  public static final long tkc_video_editor_add_mv = 9445382L;
  public static final long tkc_video_editor_add_sticker = 9445383L;
  public static final long tkc_video_api_merge = 9449472L;
  public static final long tkc_video_api_mix_audio = 9449473L;
  public static final long tkc_video_api_mix_movie = 9449474L;
  public static final long tkc_video_api_movie_clipper = 9449475L;
  public static final long tkc_video_api_record_audio = 9449476L;
  public static final long tkc_video_api_extractot_video_images = 9449477L;
  public static final long tkc_video_api_movie_compresser = 9449478L;
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKVideo-3.4.1.jar!\org\lasque\tusdk\video\secrets\TuSDKVideoStatistics.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
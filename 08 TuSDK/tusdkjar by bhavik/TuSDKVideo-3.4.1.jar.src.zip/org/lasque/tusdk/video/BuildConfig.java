package org.lasque.tusdk.video;

public final class BuildConfig
{
  public static final boolean DEBUG = false;
  public static final String APPLICATION_ID = "org.lasque.tusdk.video";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "1.7";
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKVideo-3.4.1.jar!\org\lasque\tusdk\video\BuildConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
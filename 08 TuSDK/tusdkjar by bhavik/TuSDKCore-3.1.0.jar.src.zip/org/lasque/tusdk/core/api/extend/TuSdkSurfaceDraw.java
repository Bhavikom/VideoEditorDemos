package org.lasque.tusdk.core.api.extend;

public abstract interface TuSdkSurfaceDraw
{
  public abstract int onDrawFrame(int paramInt1, int paramInt2, int paramInt3, long paramLong);
  
  public abstract void onDrawFrameCompleted();
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\api\extend\TuSdkSurfaceDraw.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
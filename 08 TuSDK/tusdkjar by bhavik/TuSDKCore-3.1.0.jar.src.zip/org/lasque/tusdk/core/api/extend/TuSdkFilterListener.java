package org.lasque.tusdk.core.api.extend;

import org.lasque.tusdk.core.seles.tusdk.FilterWrap;

public abstract interface TuSdkFilterListener
{
  public abstract void onFilterChanged(FilterWrap paramFilterWrap);
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\api\extend\TuSdkFilterListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
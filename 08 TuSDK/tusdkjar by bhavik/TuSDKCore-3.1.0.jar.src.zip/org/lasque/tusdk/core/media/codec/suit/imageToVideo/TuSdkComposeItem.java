package org.lasque.tusdk.core.media.codec.suit.imageToVideo;

public class TuSdkComposeItem
{
  protected TuSdkComposeType mComposeType;
  
  public TuSdkComposeType getComposeType()
  {
    return this.mComposeType;
  }
  
  public static enum TuSdkComposeType
  {
    private TuSdkComposeType() {}
  }
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\media\codec\suit\imageToVideo\TuSdkComposeItem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
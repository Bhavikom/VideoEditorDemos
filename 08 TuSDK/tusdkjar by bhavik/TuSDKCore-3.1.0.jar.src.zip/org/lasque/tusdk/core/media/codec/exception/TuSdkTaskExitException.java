package org.lasque.tusdk.core.media.codec.exception;

public class TuSdkTaskExitException
  extends Exception
{
  public TuSdkTaskExitException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\media\codec\exception\TuSdkTaskExitException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
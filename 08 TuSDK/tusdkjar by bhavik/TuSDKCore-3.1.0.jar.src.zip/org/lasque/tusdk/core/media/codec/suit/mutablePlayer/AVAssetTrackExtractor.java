package org.lasque.tusdk.core.media.codec.suit.mutablePlayer;

import android.annotation.TargetApi;

@TargetApi(16)
public abstract interface AVAssetTrackExtractor
  extends AVAssetTrackOutputSouce
{}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\media\codec\suit\mutablePlayer\AVAssetTrackExtractor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
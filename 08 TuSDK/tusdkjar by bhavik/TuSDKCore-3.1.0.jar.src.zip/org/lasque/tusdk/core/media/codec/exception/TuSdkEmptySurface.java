package org.lasque.tusdk.core.media.codec.exception;

public class TuSdkEmptySurface
  extends Exception
{
  public TuSdkEmptySurface(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\media\codec\exception\TuSdkEmptySurface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
package org.lasque.tusdk.core.utils.hardware;

public class CameraConfigs
{
  public static enum CameraWhiteBalance
  {
    private CameraWhiteBalance() {}
  }
  
  public static enum CameraAntibanding
  {
    private CameraAntibanding() {}
  }
  
  public static enum CameraAutoFocus
  {
    private CameraAutoFocus() {}
  }
  
  public static enum CameraFacing
  {
    private CameraFacing() {}
  }
  
  public static enum CameraFlash
  {
    private CameraFlash() {}
  }
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\utils\hardware\CameraConfigs.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
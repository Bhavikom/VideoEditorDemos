package org.lasque.tusdk.core.http;

public abstract interface JsonValueInterface
{
  public abstract byte[] getEscapedJsonValue();
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\http\JsonValueInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
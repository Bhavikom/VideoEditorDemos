package org.lasque.tusdk.core.type;

public enum ColorFormatType
{
  private ColorFormatType() {}
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\type\ColorFormatType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
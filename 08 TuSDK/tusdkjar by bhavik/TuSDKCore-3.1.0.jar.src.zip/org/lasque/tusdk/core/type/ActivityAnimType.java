package org.lasque.tusdk.core.type;

public abstract interface ActivityAnimType
{
  public abstract int getEnterAnim();
  
  public abstract int getExitAnim();
  
  public abstract String name();
  
  public abstract int getAnim(boolean paramBoolean);
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\type\ActivityAnimType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
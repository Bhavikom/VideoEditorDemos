package org.lasque.tusdk.core.task;

import android.graphics.Bitmap;

public class FiltersTaskImageResult
{
  private Bitmap a;
  private String b;
  
  public Bitmap getImage()
  {
    return this.a;
  }
  
  public void setImage(Bitmap paramBitmap)
  {
    this.a = paramBitmap;
  }
  
  public String getFilterName()
  {
    return this.b;
  }
  
  public void setFilterName(String paramString)
  {
    this.b = paramString;
  }
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\task\FiltersTaskImageResult.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
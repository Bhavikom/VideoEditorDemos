package org.lasque.tusdk.core.seles.tusdk.filters.colors;

import org.lasque.tusdk.core.seles.filters.SelesTwoInputFilter;

public class TuSDKColorNoirFilter
  extends SelesTwoInputFilter
{
  public TuSDKColorNoirFilter()
  {
    super("-sc3");
    disableSecondFrameCheck();
  }
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\seles\tusdk\filters\colors\TuSDKColorNoirFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
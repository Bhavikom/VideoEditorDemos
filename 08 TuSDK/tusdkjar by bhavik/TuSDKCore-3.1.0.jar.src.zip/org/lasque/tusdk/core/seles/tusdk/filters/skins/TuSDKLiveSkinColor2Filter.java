package org.lasque.tusdk.core.seles.tusdk.filters.skins;

import org.lasque.tusdk.core.seles.tusdk.FilterOption;

public class TuSDKLiveSkinColor2Filter
  extends TuSDKSkinColor2Filter
{
  public TuSDKLiveSkinColor2Filter() {}
  
  public TuSDKLiveSkinColor2Filter(FilterOption paramFilterOption)
  {
    super(paramFilterOption);
  }
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\seles\tusdk\filters\skins\TuSDKLiveSkinColor2Filter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
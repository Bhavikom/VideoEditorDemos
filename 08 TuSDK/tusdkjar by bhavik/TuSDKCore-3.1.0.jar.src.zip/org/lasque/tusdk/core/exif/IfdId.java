package org.lasque.tusdk.core.exif;

public abstract interface IfdId
{
  public static final int TYPE_IFD_0 = 0;
  public static final int TYPE_IFD_1 = 1;
  public static final int TYPE_IFD_EXIF = 2;
  public static final int TYPE_IFD_INTEROPERABILITY = 3;
  public static final int TYPE_IFD_GPS = 4;
  public static final int TYPE_IFD_COUNT = 5;
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\exif\IfdId.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
package org.lasque.tusdk.core.listener;

import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

public class AnimationListenerAdapter
  implements Animation.AnimationListener
{
  public void onAnimationStart(Animation paramAnimation) {}
  
  public void onAnimationEnd(Animation paramAnimation) {}
  
  public void onAnimationRepeat(Animation paramAnimation) {}
}


/* Location:              C:\Users\OM\Desktop\tusdkjar\TuSDKCore-3.1.0.jar!\org\lasque\tusdk\core\listener\AnimationListenerAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */
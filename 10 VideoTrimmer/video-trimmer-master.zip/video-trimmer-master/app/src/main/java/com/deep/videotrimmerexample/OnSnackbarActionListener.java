package com.deep.videotrimmerexample;

/**
 * Created by Deep Patel
 */

public interface OnSnackbarActionListener {
    void onAction();
}

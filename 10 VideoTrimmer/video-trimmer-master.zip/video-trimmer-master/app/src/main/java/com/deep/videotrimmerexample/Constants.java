package com.deep.videotrimmerexample;

/**
 * Created by Deep Patel
 * (Sr. Android Developer)
 * on 6/4/2018
 */
public class Constants {
    public static final String EXTRA_VIDEO_PATH = "EXTRA_VIDEO_PATH";
    public static String croppedVideoURI;
}

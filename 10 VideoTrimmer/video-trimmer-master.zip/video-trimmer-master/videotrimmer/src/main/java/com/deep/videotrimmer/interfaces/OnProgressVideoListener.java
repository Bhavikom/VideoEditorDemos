
package com.deep.videotrimmer.interfaces;

/**
 * Created by Deep Patel
 * (Sr. Android Developer)
 * on 6/4/2018
 */

public interface OnProgressVideoListener {

    void updateProgress(int time, int max, float scale);
}
